//
//  MyCollectionCell.swift
//  collection view 2 cell
//
//  Created by MAC OS on 24/01/22.
//

import UIKit

class MyCollectionCell: UICollectionViewCell {
    
    @IBOutlet var MyImage: UIImageView!
}
